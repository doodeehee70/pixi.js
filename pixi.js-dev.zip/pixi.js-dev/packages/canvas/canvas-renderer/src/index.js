export { default as CanvasRenderer } from './CanvasRenderer';
export { default as canUseNewCanvasBlendModes } from './utils/canUseNewCanvasBlendModes';
export { default as CanvasTinter } from './CanvasTinter';

import './Renderer';
import './BaseTexture';
