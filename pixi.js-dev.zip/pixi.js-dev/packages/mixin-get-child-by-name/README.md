# @pixi/mixin-get-child-by-name

## Installation

```bash
npm install @pixi/mixin-get-child-by-name
```

## Usage

```js
import '@pixi/mixin-get-child-by-name';
```