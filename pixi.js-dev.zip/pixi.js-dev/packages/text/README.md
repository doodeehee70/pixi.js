# @pixi/text

## Installation

```bash
npm install @pixi/text
```

## Usage

```js
import * as text from '@pixi/text';
```