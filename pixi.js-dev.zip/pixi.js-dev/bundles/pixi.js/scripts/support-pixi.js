/* eslint-disable no-console */

const green = '\u001b[32m';
const white = '\u001b[22m\u001b[39m';
const boldCyan = '\u001b[96m\u001b[1m';
const reset = '\u001b[0m';

console.log(`${green}Have some ❤️  for PixiJS? You can support the project via OpenCollective:`);
console.log(`${white}> ${boldCyan}https://opencollective.com/pixijs/contribute\n${reset}`);
